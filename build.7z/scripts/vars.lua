screenx = 480
screeny = 80
screenw = 800
screenh = 600
title = "G"

fullscreen = true